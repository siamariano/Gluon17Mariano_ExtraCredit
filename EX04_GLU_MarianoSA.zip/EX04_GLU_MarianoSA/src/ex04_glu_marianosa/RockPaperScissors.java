//EX04_GLU_MarianoSA
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex04_glu_marianosa;

/**
 *
 * @author SOPHIA ISABEL
 */ 
import java.util.Scanner;

public class RockPaperScissors {
    public static void main(String[] args){
        Move rock = new Move("Rock");
        Move paper = new Move("Paper");
        Move scissors = new Move("Scissors");
		
        rock.setStrongAgainst(scissors);
        paper.setStrongAgainst(rock);
        scissors.setStrongAgainst(paper);
		
	int roundsToWin = 2;
        
        while (true){
            System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option.");
            System.out.println("1. Start game");
            System.out.println("2. Change number of rounds");
            System.out.println("3. Exit application");
            Scanner playerInput = new Scanner(System.in);
            int playerOption = playerInput.nextInt();
        
            if (playerOption == 3){
                 System.out.println("\nThank you for playing!");
                 break;
            } else if (playerOption == 2){
                 System.out.println("\nHow many wins are needed to win a match?");
                 Scanner wins = new Scanner(System.in);
                 roundsToWin = wins.nextInt();
                 System.out.println("New setting has been saved!\n");
            } else if (playerOption == 1){
                 System.out.println("\nThis match will be first to " + roundsToWin + " wins.");
                 
                 int playerWins = 0; //number of wins of player
                 int computerWins = 0; //number of wins of computer
            
                 while (playerWins < roundsToWin && computerWins <roundsToWin){
                     int random = (int) Math.floor(Math.random()*3) + 1;

                     System.out.println("The computer has selected its move. Select your move.");
                     System.out.println("1. Rock");
                     System.out.println("2. Paper");
                     System.out.println("3. Scissors");
                     Scanner playerMove = new Scanner (System.in);
                     int playersNumber = playerMove.nextInt() ; //reads number that player input
                
                     Move computerChoice = null; //computer's move
                     Move playerChoice = null; //player's move
            
                     switch (random){ //assigns move (computer)
                         case 1:
                             computerChoice = rock;
                             break;
                         case 2:
                             computerChoice = paper;
                             break;
                         case 3:
                              computerChoice = scissors;
                              break;
                     }
                
                      switch (playersNumber){ //assigns move (player)
                         case 1:
                             playerChoice = rock;
                             break;
                         case 2:
                             playerChoice = paper;
                             break;
                         case 3:
                             playerChoice = scissors;
                             break;
                     }
                
                     int result = Move.compareMoves(computerChoice, playerChoice);
                
                     if (result == 0){
                         System.out.println("\nPlayer chose " + playerChoice.getName() + ". Computer chose " + computerChoice.getName() + ". Computer wins round!");
                         computerWins++;
                         System.out.println("Player: " + playerWins + " - Computer: " + computerWins);
                     } else if (result == 1){
                         System.out.println("\nPlayer chose " + playerChoice.getName() + ". Computer chose " + computerChoice.getName() + ". Player wins round!");
                         playerWins++;
                         System.out.println("Player: " + playerWins + " - Computer: " + computerWins);
                     } else if (result == 2){
                         System.out.println("\nPlayer chose " + playerChoice.getName() + ". Computer chose " + computerChoice.getName() + ". Round is tied!");
                         System.out.println("Player: " + playerWins + " - Computer: " + computerWins);
                     }

                }
                 if (computerWins > playerWins){
                    System.out.println("\nComputer wins!\n");
                } else {
                    System.out.println("\nPlayer wins!\n");
                }
           
            } 
        }
        
        
    }
    
}
