/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_glu_marianosa;

/**
 *
 * @author SOPHIA ISABEL
 */
public class Song {
    private String songTitle; //title of song (String T)
    private String songArtist;//singer of song (String A)
    private int yearReleased;//year the song was released (int y)
    private float songDuration;//how long the song plays in minutes (float sD)
    
    public Song(String T, String A, int y, float sD){
        songTitle = T;
        songArtist = A;
        yearReleased = y;
        songDuration = sD;
    }
    public void singSong(){
        System.out.println(songTitle + " is being sung."); //shows if song is being sung
    }
    public String getSongTitle(){
        return songTitle;
    }
    public String getSongArtist(){
        return songArtist;
    }
    public int getYearReleased(){
        return yearReleased;
    }
    
    public float getSongDuration(){
        return songDuration;
    }
    
    
}
