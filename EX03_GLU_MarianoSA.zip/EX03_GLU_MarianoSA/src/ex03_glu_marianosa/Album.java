/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_glu_marianosa;

/**
 *
 * @author SOPHIA ISABEL
 */
public class Album {
   private String albumTitle; //title of album
   private String albumArtist; //artist of the album
   private int noOfSongs; //number of songs in the album
   
   public Album(String t, String a, int nS){
       albumTitle = t;
       albumArtist = a;
       noOfSongs = nS;
   }
   public String getAlbumTitle(){
       return albumTitle;
   }
   public String getAlbumArtist(){
       return albumArtist;
   }
   public int getNoOfSongs(){
       return noOfSongs;
   }
   
}
