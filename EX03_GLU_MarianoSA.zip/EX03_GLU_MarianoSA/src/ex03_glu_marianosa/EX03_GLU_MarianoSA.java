/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex03_glu_marianosa;

/**
 *
 * @author SOPHIA ISABEL
 */
public class EX03_GLU_MarianoSA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Album album1 = new Album("Nothing Happens", "Wallows", 11);
        System.out.println("Album title: " + album1.getAlbumTitle());
        System.out.println("Album artist: " + album1.getAlbumArtist());
        System.out.println("Number of songs: " + album1.getNoOfSongs() + "\n");
        
        Album album2 = new Album("Tell Me That It's Over", "Wallows", 10);
        System.out.println("Album title: " + album2.getAlbumTitle());
        System.out.println("Album artist: " + album2.getAlbumArtist());
        System.out.println("Number of songs: " + album2.getNoOfSongs() + "\n");
        
        Album album3 = new Album("reputation", "Taylor Swift", 15);
        System.out.println("Album title: " + album3.getAlbumTitle());
        System.out.println("Album artist: " + album3.getAlbumArtist());
        System.out.println("Number of songs: " + album3.getNoOfSongs() + "\n");
        
       //song class
       Song song1 = new Song("august", "Taylor Swift", 2020, (float) 4.35);
       System.out.println("Song title: " + song1.getSongTitle());
       System.out.println("Song artist: " + song1.getSongArtist());
       System.out.println("Year released: " + song1.getYearReleased());
       System.out.println("Song duration: " + song1.getSongDuration());
       song1.singSong();
       System.out.println("\n");
       
       Song song2 = new Song("Lover", "Taylor Swift", 2019, (float) 3.04);
       System.out.println("Song title: " + song2.getSongTitle());
       System.out.println("Song artist: " + song2.getSongArtist());
       System.out.println("Year released: " + song2.getYearReleased());
       System.out.println("Song duration: " + song2.getSongDuration());
       song2.singSong();
       System.out.println("\n");
        
       //singer class
       Song favoriteSong = new Song ("this is me trying", "Taylor Swift", 2020, (float)3.04);
       Singer singer1 = new Singer ("Gracie Abrams", favoriteSong);
       System.out.println("Singer: " + singer1.getName());
       System.out.println("Favorite Song: " + favoriteSong.getSongTitle() + " by " + favoriteSong.getSongArtist());
       singer1.performForAudience(12);
       Song newFavSong = new Song("august", "Taylor Swift", 2020, (float)3.00);
       singer1.changeFavSong(newFavSong);
       System.out.println("\n");
       
       Song favoriteSong2 = new Song ("cardigan", "Taylor Swift", 2020, (float)3.02);
       Singer singer2 = new Singer ("Taylor Sheesh", favoriteSong2);
       System.out.println(singer2.getName() + " will now perform with " + singer1.getName());
       singer2.performForAudience(12, 2);
       singer1.performForAudience(12, 2);
       System.out.println(singer1.getName() + "'s total earnings: " + singer1.getEarnings());
       System.out.println(singer2.getName() + "'s total earnings: " + singer2.getEarnings());
       System.out.println("Total performances: " + Singer.getTotalPerformances()); 
       /*Their performance together is counted as separate performances. One for each singer */
       
    }
}

