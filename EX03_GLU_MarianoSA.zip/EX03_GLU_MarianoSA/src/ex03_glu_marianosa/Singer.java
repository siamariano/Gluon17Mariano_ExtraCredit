/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_glu_marianosa;

/**
 *
 * @author SOPHIA ISABEL
 */
public class Singer {
    private String name; //N
    private int noOfPerformances; //nP
    private double earnings; //e
    private static int totalPerformances;
    
    public Singer(String nA, Song song){
        name = nA;
        noOfPerformances = 0;
        earnings = 0;
    }
    public void performForAudience(int n){
        totalPerformances++;
        noOfPerformances++;
        setEarnings(earnings + (100 * n));
        System.out.println("Number of performances: " + getNoOfPerformances());
        System.out.println("Earnings: " + getEarnings());
    }
    public  void performForAudience(int n, int nOS){
        totalPerformances++;
        noOfPerformances++;
        int tE = 100 * n; //gets total earnings by mutiplying 100 to number of people in audience
        setEarnings(earnings + (tE / nOS)); //divides total earnings by number of singers
    }
    public void changeFavSong(Song song){
        System.out.println("New favorite song: " + song.getSongTitle() + " by " + song.getSongArtist());
    }

    public String getName() {
        return name;
    }
    public int getNoOfPerformances() {
        return noOfPerformances;
    }

    public double getEarnings() {
        return earnings;
    }
    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }
    public static int getTotalPerformances() {
        return totalPerformances;
    }
    
    
}
