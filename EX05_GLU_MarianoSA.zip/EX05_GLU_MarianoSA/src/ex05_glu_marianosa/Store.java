/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex05_glu_marianosa;

/**
 *
 * @author SOPHIA ISABEL
 */
import java.util.ArrayList;

public class Store {
  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList();

  public Store(String name){
    // Initialize name to parameter and earnings to zero
    // Initialize itemList as a new ArrayList
    // add 'this' store to storeList
    this.name = name;
    earnings = 0;
    itemList = new ArrayList();
    storeList.add(this);
  }

  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
    // get Item at index from itemList and add its cost to earnings
    // print statement indicating the sale
    if (index < itemList.size()){
        Item item = itemList.get(index);
        earnings += item.getCost();
        System.out.println(item.getName() + " has been sold for " + item.getCost());
    } else if(index > itemList.size()){
        System.out.println("There are only " + itemList.size() + " items in the store.");
    }
    System.out.println(" ");
  }
  public void sellItem(String name){
    // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
    // get Item from itemList and add its cost to earnings
    // print statement indicating the sale
    boolean found = false;
    for (Item item : itemList){
        if (item.getName().equals(name)){
            found = true;
            earnings += item.getCost();
            System.out.println(item.getName() + " has been sold for " + item.getCost());  
            break;
        }   
        
    }
    if(!found){
       System.out.println("The store doesn't sell " + name); 
    }
    System.out.println(" ");
  }
  public void sellItem(Item i){
    // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
    // get Item i from itemList and add its cost to earnings
    // print statement indicating the sale
    if (itemList.contains(i)){
        earnings += i.getCost();
        System.out.println(i.getName() + " has been sold for " + i.getCost());
    } else if (!itemList.contains(i)){
        System.out.println("The store doesn't sell " + i.getName());
    }
    System.out.println(" ");
  }
  public void addItem(Item i){
    // add Item i to store's itemList
    itemList.add(i);
  }
  public void filterType(String type){
    // loop over itemList and print all items with the specified type
    Store store = this;
    System.out.println("The following items are " + type + " found in " + store.getName());
    for (Item item : itemList){
        if (item.getType().equalsIgnoreCase(type)){
            System.out.println(item.getName());
        }
    }
    System.out.println(" ");
  }
  public void filterCheap(double maxCost){
    // loop over itemList and print all items with a cost lower than or equal to the specified value
    Store store = this;
    System.out.println("The following items cost cheaper than or equal to " + maxCost + " at " + store.getName());
    for (Item item : itemList){
        if (item.getCost() <= maxCost){
            System.out.println(item.getName());
        }
    }
   System.out.println(" ");
  }
  public void filterExpensive(double minCost){
    // loop over itemList and print all items with a cost higher than or equal to the specified value
    Store store = this;
    System.out.println("The following items cost more expensive than or equal to " + minCost + " at " + store.getName());
    for (Item item : itemList){
        if (item.getCost() >= minCost){
            System.out.println(item.getName());
        }
    }
    System.out.println(" ");
  }
  public static void printStats(){
    // loop over storeList and print the name and the earnings'Store.java'
    storeList.forEach(Store -> System.out.println(Store.getName() + " earnings: " + Store.getEarnings()));
  }
}
