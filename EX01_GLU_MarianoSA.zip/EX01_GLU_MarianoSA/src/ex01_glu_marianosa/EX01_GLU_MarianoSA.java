/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex01_glu_marianosa;

/**
 *
 * @author SOPHIA ISABEL
 */
public class EX01_GLU_MarianoSA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String Album1 = "folklore(deluxe version)";
        String Album2 = "evermore(deluxe version)";
        String Album3 = "Tell Me That It's Over";
        
        System.out.println(Album1); //album name (1)
        String albumArtist1 = "Taylor Swift"; //artist of album 1
        System.out.println("Artist: " + albumArtist1); 
        int numberOfsongs1 = 17; //number of songs in album 1
        System.out.println("Number of songs: " + numberOfsongs1);
        float albumLength1 = (float) 1.116; //running time of album 1
        System.out.println("Running time: " + albumLength1 + " hours\n");
        
        System.out.println(Album2); //album name (2)
        String albumArtist2 = "Taylor Swift"; //artist of album 2
        System.out.println("Artist: " + albumArtist2);
        int numberOfsongs2 = 17; //number of songs in album 2
        System.out.println("Number of songs: " + numberOfsongs2);
        float albumLength2 = (float) 1.150; //running time of album 2
        System.out.println("Running time: " + albumLength2 + " hours\n");
        
        System.out.println(Album3); //album name (3)
        String albumArtist3 = "Wallows"; //artist of album 3
        System.out.println("Artist: " + albumArtist3);
        int numberOfsongs3 = 10; // number of songs in album 3
        System.out.println("Number of songs: " + numberOfsongs3);
        float albumLength3 = (float) 0.5661; //running time of album 3
        System.out.println("Running time: " + albumLength3 + " hours\n");
        
        boolean compareArtists = (albumArtist1 == albumArtist2) 
                && (albumArtist2 == albumArtist3); 
        System.out.println("All albums are by the same artist: " + compareArtists);
        //compares if albums have the same artist
        
        boolean compareSongnumbers = numberOfsongs1 > numberOfsongs2;
        System.out.println(Album1 + " has more "
                + "songs than " + Album2 + ": " + compareSongnumbers);
        /*compares if folklore(deluxe version) has more songs than 
        evermore(deluxe version)*/
        
        boolean compareSongnumbers2 = numberOfsongs2 == numberOfsongs3;
        System.out.println( Album2 + " has the same number of"
                + " songs as " + Album3 + ": " + compareSongnumbers2);
        /*compares if evermore(deluxe version) and Tell Me That It's Over
        have the same number of songs*/
        
        int subtractSongs = numberOfsongs2 - numberOfsongs3;
        System.out.println(Album2 + " has " + subtractSongs + 
                " more songs than " + Album3 + ".");
        /*finds how much more songs evermore(deluxe version) has over 
        Tell Me That It's Over*/
        
        float totalRunningtime = (float) albumLength1 + albumLength2 + albumLength3;
        System.out.println("Total running time of all albums: " + totalRunningtime
        + " hours");
        /*Adds the running time of all three albums*/
        
        
    }
    
}
